$(document).ready(function(){


    $('.experiance ul li').click(function(){
        $('.experiance ul li').removeClass('active')
        $(this).addClass('active')
        
    }),
    
    $('.certificate ul li').click(function(){
        $('.certificate ul li').removeClass('active')
        $(this).addClass('active')
        
    });

    $('.major ul li').click(function(){
        $('.major ul li').removeClass('active')
        $(this).addClass('active')
        
    })


})